/**
 * 
 */
/**
 * @author chandni.v
 *@see will introduce Profile in spring with annotation
 *and make different set of beans or configurations available
 *conditionally.
 *
 *For Example assuyme DEV - ORACLE , Testing 
 */
package com.trainings.profile;