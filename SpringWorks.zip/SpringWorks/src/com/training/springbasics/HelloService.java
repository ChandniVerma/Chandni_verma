package com.training.springbasics;

public interface HelloService {

	String sayHello(String name, String city);

	String sayHello();
	
	

}
