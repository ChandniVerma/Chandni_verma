package com.training.hello;

public class GreetFrench implements Greeting{

	@Override
	public String greetHello() {
		// TODO Auto-generated method stub
		return "Bonjour tout le monde";
	}

}
