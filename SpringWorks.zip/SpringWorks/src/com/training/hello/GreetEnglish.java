package com.training.hello;

public class GreetEnglish implements Greeting{

	@Override
	public String greetHello() {
		// TODO Auto-generated method stub
		return "Hello its mondays";
	}
	

}
