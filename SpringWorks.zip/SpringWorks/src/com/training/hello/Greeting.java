package com.training.hello;

public interface Greeting {
	public String greetHello();

}
